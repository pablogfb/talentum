load 'Conectividad.rb'
load 'Disco.rb'
load 'Grafica.rb'
load 'Procesador.rb'
load 'Puertos.rb'
load 'Ram.rb'
load 'Componente.rb'

class Ordenador
  
    
  def initialize disco, procesador, puertos, ram, conectividad, grafica
    @disco=disco
    @procesador=procesador
    @puertos=puertos
    @ram=ram
    @conectividad=conectividad
    @grafica=grafica
  end
  
  def precio_total
    @total= @disco.precio.to_i+@procesador.precio.to_i+@puertos.precio.to_i+@ram.precio.to_i+@conectividad.precio.to_i+@grafica.precio.to_i
  end
  
   def to_s
        "Descripción de componentes:\n#{@disco}#{@procesador}#{@puertos}#{@ram}#{@conectividad}#{@grafica}El precio total: #{precio_total} €"
  end
end