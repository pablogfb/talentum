load 'Componente.rb'

class Conectividad < Componente
  attr_accessor :wifi, :bluetooh,:rj45
  def initialize wifi, bluetooh, rj45, fabricante, precio
    @wifi=wifi
    @bluetooh=bluetooh
    @rj45=rj45
    super fabricante, precio
  end
  def to_s
    "Conectividad: #{wifi}, #{bluetooh}, #{rj45}, #{@fabricante}, #{@precio}\n"
  end
end
