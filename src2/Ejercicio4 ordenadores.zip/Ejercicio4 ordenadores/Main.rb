load 'Conectividad.rb'
load 'Disco.rb'
load 'Grafica.rb'
load 'Procesador.rb'
load 'Puertos.rb'
load 'Ram.rb'
load 'Ordenador.rb'


disco= Disco.new "memoria", "modelo", "velocidad", "fabricante", 225  
procesador= Procesador.new "frecuencia", "modelo", "nucleos", "fabricante", 350
puertos=Puertos.new "usb","usb3","hdmi", "fabricante", 23
ram=Ram.new "memoria", "tipo", "fabricante", 153
conectividad=Conectividad.new "wifi", "bluetooh", "rj45", "fabricante", 150
grafica=Grafica.new "memoria", "modelo", "fabricante", 200

ordenador= Ordenador.new disco, procesador, puertos, ram, conectividad, grafica

puts ordenador


